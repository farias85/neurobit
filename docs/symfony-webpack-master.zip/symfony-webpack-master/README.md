# symfony-webpack

## About
How to integrate Webpack Encore into Symfony Application

## Installation
This package is distributed via npm:
```
$ git clone git@github.com:nioperas06/symfony-webpack.git
$ cd symfony-webpack
$ npm install
$ composer update
$ php bin/console server:start

```
Now open page http://127.0.0.1:8000/ in your browser and enjoy! 😎
